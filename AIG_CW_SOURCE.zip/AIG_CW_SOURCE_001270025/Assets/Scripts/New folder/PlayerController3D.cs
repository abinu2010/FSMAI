using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController3D : MonoBehaviour
{
    [Header("Movement")]
    public float walkSpeed = 3f;
    public float sprintSpeed = 6f;
    public float crouchSpeed = 1.5f;
    public float gravity = -15f;
    public float groundedGravity = -2f;

    [Header("Camera")]
    public Transform cameraTransform;
    public float turnSmoothTime = 0.1f;

    [Header("Crouch")]
    public float standingHeight = 2f;
    public float crouchHeight = 1f;
    public float crouchTransitionSpeed = 10f;

    [Header("Keys")]
    public KeyCode sprintKey = KeyCode.LeftShift;
    public KeyCode crouchKey = KeyCode.LeftControl;

    private CharacterController controller;
    private float turnSmoothVelocity;
    private Vector3 velocity;
    private float targetHeight;
    private float currentHeight;

    public bool IsSprinting { get; private set; }
    public bool IsCrouching { get; private set; }
    public float CurrentSpeed { get; private set; }

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        currentHeight = standingHeight;
        targetHeight = standingHeight;
        controller.height = standingHeight;

        Debug.Log("[PlayerController3D] Ready");
    }

    void Update()
    {
        HandleCrouching();
        HandleMovement();
        ApplyGravity();
    }

    void HandleCrouching()
    {
        bool crouchInput = Input.GetKey(crouchKey);
        bool sprintInput = Input.GetKey(sprintKey);

        if (crouchInput && !sprintInput)
        {
            targetHeight = crouchHeight;
            IsCrouching = true;
            IsSprinting = false;
        }
        else
        {
            targetHeight = standingHeight;
            IsCrouching = false;

            if (sprintInput && !crouchInput)
            {
                IsSprinting = true;
            }
            else
            {
                IsSprinting = false;
            }
        }

        if (Mathf.Abs(currentHeight - targetHeight) > 0.01f)
        {
            currentHeight = Mathf.Lerp(currentHeight, targetHeight, Time.deltaTime * crouchTransitionSpeed);
            controller.height = currentHeight;

            Vector3 center = controller.center;
            center.y = currentHeight / 2f;
            controller.center = center;
        }
    }

    void HandleMovement()
    {
        float horizontal = Input.GetAxisRaw("Horizontal");
        float vertical = Input.GetAxisRaw("Vertical");
        Vector3 direction = new Vector3(horizontal, 0f, vertical).normalized;

        if (direction.magnitude >= 0.1f)
        {
            float targetAngle = Mathf.Atan2(direction.x, direction.z) * Mathf.Rad2Deg;

            if (cameraTransform != null)
            {
                targetAngle += cameraTransform.eulerAngles.y;
            }

            float angle = Mathf.SmoothDampAngle(
                transform.eulerAngles.y,
                targetAngle,
                ref turnSmoothVelocity,
                turnSmoothTime
            );

            transform.rotation = Quaternion.Euler(0f, angle, 0f);

            Vector3 moveDir = Quaternion.Euler(0f, targetAngle, 0f) * Vector3.forward;

            float speed = walkSpeed;
            if (IsSprinting)
            {
                speed = sprintSpeed;
            }
            else if (IsCrouching)
            {
                speed = crouchSpeed;
            }

            CurrentSpeed = speed;
            controller.Move(moveDir.normalized * speed * Time.deltaTime);
        }
        else
        {
            CurrentSpeed = 0f;
        }
    }

    void ApplyGravity()
    {
        if (controller.isGrounded)
        {
            if (velocity.y < 0f)
            {
                velocity.y = groundedGravity;
            }
        }
        else
        {
            velocity.y += gravity * Time.deltaTime;
        }

        controller.Move(velocity * Time.deltaTime);
    }

    public Vector3 GetVelocity()
    {
        return controller.velocity;
    }

    public bool IsGrounded()
    {
        return controller.isGrounded;
    }

    public bool IsMoving()
    {
        return controller.velocity.magnitude > 0.1f;
    }
}